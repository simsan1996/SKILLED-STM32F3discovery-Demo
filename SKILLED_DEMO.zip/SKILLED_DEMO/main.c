/*
 jk ChibiOS - Copyright (C) 2006..2018 Giovanni Di Sirio

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

 http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
 */

#include "ch.h"
#include "hal.h"
#include "chprintf.h"
#include "shell.h"
#include "lsm303dlhc.h"
#define cls(chp)  chprintf(chp, "\033[2J\033[1;1H")
#define SHELL_WA_SIZE   THD_WORKING_AREA_SIZE(2048)

size_t s;
static mutex_t mtx1;
static float value_X;
static float value_Y;
static float value_Z;
struct coordinates {
  bool x_neg;
  bool y_neg;
  bool z_neg;
};
static int life = 3;
static int score = 0;
static int r;

struct coordinates left;
struct coordinates right;
struct coordinates forward;
struct coordinates backward;

struct coordinates orig_F;
struct coordinates orig_R;
struct coordinates orig_B;
struct coordinates orig_L;

static bool Left = FALSE;
static bool Right = FALSE;
static bool Forward = FALSE;
static bool Backward = FALSE;

static bool EnemiesLeft = FALSE;
static bool EnemiesRight = FALSE;
static bool EnemiesForward = FALSE;
static bool EnemiesBackward = FALSE;

static float comp_x_axis;
static float comp_y_axis;
static float comp_z_axis;
static float compcooked[LSM303DLHC_COMP_NUMBER_OF_AXES];

static char axisID[LSM303DLHC_ACC_NUMBER_OF_AXES] = {'X', 'Y', 'Z'};
//driver used for the Compass
static LSM303DLHCDriver LSM303DLHCD1;

static const I2CConfig i2ccfg = {STM32_TIMINGR_PRESC(
    15U) | STM32_TIMINGR_SCLDEL(4U)
    | STM32_TIMINGR_SDADEL(2U)
    | STM32_TIMINGR_SCLH(15U)
    | STM32_TIMINGR_SCLL(21U),
                                 0, 0};

static const LSM303DLHCConfig lsm303dlhccfg = {&I2CD1, &i2ccfg, NULL, NULL,
                                               LSM303DLHC_ACC_FS_4G,
                                               LSM303DLHC_ACC_ODR_100Hz,
#if LSM303DLHC_USE_ADVANCED
                                               LSM303DLHC_ACC_LP_DISABLED,
                                               LSM303DLHC_ACC_HR_DISABLED,
                                               LSM303DLHC_ACC_BDU_BLOCK,
                                               LSM303DLHC_ACC_END_LITTLE,
#endif
                                               NULL,
                                               NULL, LSM303DLHC_COMP_FS_1P3GA,
                                               LSM303DLHC_COMP_ODR_30HZ,
#if LSM303DLHC_USE_ADVANCED
    LSM303DLHC_COMP_MD_BLOCK
#endif
  };


static BaseSequentialStream* chp = (BaseSequentialStream*)&SD1;
//all the isNameMethod() are used to verify if something is correct or not. isLeft() verify if the direction read from the Compass is Left or not.
static void isLeft() {
  bool isDirectionOK_x = FALSE;
  bool isDirectionOK_y = FALSE;
  bool isDirectionOK_z = FALSE;

  if ((left.x_neg && value_X < 0))
    isDirectionOK_x = TRUE;
  else if (!left.x_neg && value_X >= 0.000)
    isDirectionOK_x = TRUE;

  if ((left.y_neg && value_Y < 0))
    isDirectionOK_y = TRUE;
  else if (!left.y_neg && value_Y >= 0.000)
    isDirectionOK_y = TRUE;

  if ((left.z_neg && value_Z < 0))
    isDirectionOK_z = TRUE;
  else if (!left.z_neg && value_Z >= 0.000)
    isDirectionOK_z = TRUE;
  if (isDirectionOK_x && isDirectionOK_y && isDirectionOK_z)
    Left = TRUE;
}
static void isRight() {
  bool isDirectionOK_x = FALSE;
  bool isDirectionOK_y = FALSE;
  bool isDirectionOK_z = FALSE;

  if ((right.x_neg && value_X < 0))
    isDirectionOK_x = TRUE;
  else if (!right.x_neg && value_X >= 0.000)
    isDirectionOK_x = TRUE;

  if ((right.y_neg && value_Y < 0))
    isDirectionOK_y = TRUE;
  else if (!right.y_neg && value_Y >= 0.000)
    isDirectionOK_y = TRUE;

  if ((right.z_neg && value_Z < 0))
    isDirectionOK_z = TRUE;
  else if (!right.z_neg && value_Z >= 0.000)
    isDirectionOK_z = TRUE;
  if (isDirectionOK_x && isDirectionOK_y && isDirectionOK_z)
    Right = TRUE;
}
static void isForward() {
  bool isDirectionOK_x = FALSE;
  bool isDirectionOK_y = FALSE;
  bool isDirectionOK_z = FALSE;

  if ((forward.x_neg && value_X < 0))
    isDirectionOK_x = TRUE;
  else if (!forward.x_neg && value_X >= 0.000)
    isDirectionOK_x = TRUE;

  if ((forward.y_neg && value_Y < 0))
    isDirectionOK_y = TRUE;
  else if (!forward.y_neg && value_Y >= 0.000)
    isDirectionOK_y = TRUE;

  if ((forward.z_neg && value_Z < 0))
    isDirectionOK_z = TRUE;
  else if (!forward.z_neg && value_Z >= 0.000)
    isDirectionOK_z = TRUE;
  if (isDirectionOK_x && isDirectionOK_y && isDirectionOK_z)
    Forward = TRUE;
}
static void isBackward() {
  bool isDirectionOK_x = FALSE;
  bool isDirectionOK_y = FALSE;
  bool isDirectionOK_z = FALSE;

  if ((backward.x_neg && value_X < 0))
    isDirectionOK_x = TRUE;
  else if (!backward.x_neg && value_X >= 0.000)
    isDirectionOK_x = TRUE;

  if ((backward.y_neg && value_Y < 0))
    isDirectionOK_y = TRUE;
  else if (!backward.y_neg && value_Y >= 0.000)
    isDirectionOK_y = TRUE;

  if ((backward.z_neg && value_Z < 0))
    isDirectionOK_z = TRUE;
  else if (!backward.z_neg && value_Z >= 0.000)
    isDirectionOK_z = TRUE;
  if (isDirectionOK_x && isDirectionOK_y && isDirectionOK_z)
    Backward = TRUE;
}

//this function is responsible to read Data from the compass.

static void readData() {
  lsm303dlhcCompassReadCooked(&LSM303DLHCD1, compcooked);
  comp_x_axis = compcooked[0];
  comp_y_axis = compcooked[1];
  comp_z_axis = compcooked[2];

  value_X = comp_x_axis;
  value_Y = comp_y_axis;
  value_Z = comp_z_axis;

}
//Guys I think you know what the set method does.
// How I discriminate the direction? I saw that the simple direction: Forward, Right, Backward and Left has always a different composition of negative
// values of the three axis: x,y,z.
//Example:
//Forward: x negative, y negative, z positive.
//Backward: x negative, y positive, z positive
//Right: x positive, y negative, z negative
//Left: all negative

static void setRight() {
  float mean_X = 0.0;
  float mean_Y = 0.0;
  float mean_Z = 0.0;
  chprintf(chp, "gira la scheda alla tua destra: \r\n");
  chThdSleepMilliseconds(5000);
  for (int i = 0; i < 100; i++) {
    lsm303dlhcCompassReadCooked(&LSM303DLHCD1, compcooked);
    comp_x_axis = compcooked[0];
    comp_y_axis = compcooked[1];
    comp_z_axis = compcooked[2];

    mean_X += comp_x_axis;
    mean_Y += comp_y_axis;
    mean_Z += comp_z_axis;

  }

  value_X = mean_X / 100;
  value_Y = mean_Y / 100;
  value_Z = mean_Z / 100;
  chprintf(chp, "%c-axis: %.3f\r\n", axisID[0], value_X);
  chprintf(chp, "%c-axis: %.3f\r\n", axisID[1], value_Y);
  chprintf(chp, "%c-axis: %.3f\r\n", axisID[2], value_Z);
  if (value_X < 0)
    right.x_neg = TRUE;
  else
    right.x_neg = FALSE;
  if (value_Y < 0)
    right.y_neg = TRUE;
  else
    right.y_neg = FALSE;
  if (value_Z < 0)
    right.z_neg = TRUE;
  else
    right.z_neg = FALSE;

  orig_R.x_neg = right.x_neg;
  orig_R.y_neg = right.y_neg;
  orig_R.z_neg = right.z_neg;
}

static void setLeft() {
  float mean_X = 0.0;
  float mean_Y = 0.0;
  float mean_Z = 0.0;
  chprintf(chp, "turn the chip to left: \r\n");
  chThdSleepMilliseconds(5000);
  for (int i = 0; i < 100; i++) {
    lsm303dlhcCompassReadCooked(&LSM303DLHCD1, compcooked);
    comp_x_axis = compcooked[0];
    comp_y_axis = compcooked[1];
    comp_z_axis = compcooked[2];

    mean_X += comp_x_axis;
    mean_Y += comp_y_axis;
    mean_Z += comp_z_axis;

  }

  value_X = mean_X / 100;
  value_Y = mean_Y / 100;
  value_Z = mean_Z / 100;
  chprintf(chp, "%c-axis: %.3f\r\n", axisID[0], value_X);
  chprintf(chp, "%c-axis: %.3f\r\n", axisID[1], value_Y);
  chprintf(chp, "%c-axis: %.3f\r\n", axisID[2], value_Z);
  if (value_X < 0)
    left.x_neg = TRUE;
  else
    left.x_neg = FALSE;
  if (value_Y < 0)
    left.y_neg = TRUE;
  else
    left.y_neg = FALSE;
  if (value_Z < 0)
    left.z_neg = TRUE;
  else
    left.z_neg = FALSE;

  orig_L.x_neg = left.x_neg;
  orig_L.y_neg = left.y_neg;
  orig_L.z_neg = left.z_neg;
}
static void setForward() {
  float mean_X = 0.0;
  float mean_Y = 0.0;
  float mean_Z = 0.0;

  chprintf(chp, "turn the chip to forward: \r\n");
  chThdSleepMilliseconds(5000);
  for (int i = 0; i < 100; i++) {
    lsm303dlhcCompassReadCooked(&LSM303DLHCD1, compcooked);
    comp_x_axis = compcooked[0];
    comp_y_axis = compcooked[1];
    comp_z_axis = compcooked[2];

    mean_X += comp_x_axis;
    mean_Y += comp_y_axis;
    mean_Z += comp_z_axis;
  }

  value_X = mean_X / 100;
  value_Y = mean_Y / 100;
  value_Z = mean_Z / 100;
  chprintf(chp, "%c-axis: %.3f\r\n", axisID[0], value_X);
  chprintf(chp, "%c-axis: %.3f\r\n", axisID[1], value_Y);
  chprintf(chp, "%c-axis: %.3f\r\n", axisID[2], value_Z);
  if (value_X < 0)
    forward.x_neg = TRUE;
  else
    forward.x_neg = FALSE;
  if (value_Y < 0)
    forward.y_neg = TRUE;
  else
    forward.y_neg = FALSE;
  if (value_Z < 0)
    forward.z_neg = TRUE;
  else
    forward.z_neg = FALSE;

  orig_F.x_neg = forward.x_neg;
  orig_F.y_neg = forward.y_neg;
  orig_F.z_neg = forward.z_neg;
}
static void setBackward() {
  float mean_X = 0.0;
  float mean_Y = 0.0;
  float mean_Z = 0.0;

  chprintf(chp, "turn the chip to backward: \r\n");
  chThdSleepMilliseconds(5000);
  for (int i = 0; i < 100; i++) {
    lsm303dlhcCompassReadCooked(&LSM303DLHCD1, compcooked);
    comp_x_axis = compcooked[0];
    comp_y_axis = compcooked[1];
    comp_z_axis = compcooked[2];

    mean_X += comp_x_axis;
    mean_Y += comp_y_axis;
    mean_Z += comp_z_axis;
  }

  value_X = mean_X / 100;
  value_Y = mean_Y / 100;
  value_Z = mean_Z / 100;
  chprintf(chp, "%c-axis: %.3f\r\n", axisID[0], value_X);
  chprintf(chp, "%c-axis: %.3f\r\n", axisID[1], value_Y);
  chprintf(chp, "%c-axis: %.3f\r\n", axisID[2], value_Z);
  if (value_X < 0)
    backward.x_neg = TRUE;
  else
    backward.x_neg = FALSE;
  if (value_Y < 0)
    backward.y_neg = TRUE;
  else
    backward.y_neg = FALSE;
  if (value_Z < 0)
    backward.z_neg = TRUE;
  else
    backward.z_neg = FALSE;

  orig_B.x_neg = backward.x_neg;
  orig_B.y_neg = backward.y_neg;
  orig_B.z_neg = backward.z_neg;
}

//this method have to verify which LED need to be turned on.
static void whoIsR() {
  switch (r) {
  case 1:
    palToggleLine(LINE_LED3_RED);
    EnemiesBackward = TRUE;
    break;
  case 2:
    palToggleLine(LINE_LED10_RED);
    EnemiesForward = TRUE;
    break;
  case 3:
    palToggleLine(LINE_LED7_GREEN);
    EnemiesLeft = TRUE;
    break;
  case 4:
    palToggleLine(LINE_LED6_GREEN);
    EnemiesRight = TRUE;
    break;

  }
}
//Turn off the LED that is switched on by the whoIsR function
static void clear_LED() {
  if (EnemiesBackward) {
    palToggleLine(LINE_LED3_RED);
    EnemiesBackward = FALSE;
  }
  else if (EnemiesForward) {
    palToggleLine(LINE_LED10_RED);
    EnemiesForward = FALSE;
  }
  else if (EnemiesLeft) {
    palToggleLine(LINE_LED7_GREEN);
    EnemiesLeft = FALSE;
  }
  else if (EnemiesRight) {
    palToggleLine(LINE_LED6_GREEN);
    EnemiesRight = FALSE;
  }
  Right = FALSE;
  Left = FALSE;
  Backward = FALSE;
  Forward = FALSE;
}

// verify if the direction where the user "Shoot" match with the direction of the enemy

static bool isKilledEnemy() {
  if (Right && EnemiesRight) {
    chprintf(chp, "KILLED!\r\n");
    return TRUE;
  }
  else if (Left && EnemiesLeft) {

    chprintf(chp, "KILLED!\r\n");
    return TRUE;
  }
  else if (Backward && EnemiesBackward) {

    chprintf(chp, "KILLED!\r\n");
    return TRUE;
  }
  else if (Forward && EnemiesForward) {

    chprintf(chp, "KILLED!\r\n");
    return TRUE;
  }
  else {
    return FALSE;
  }
}

//Update the coordinates when the user push the button. If the Player push to the right, now the forward is the "old right".
//                     Forward
//              Left              Right
//                     Backward
// push the Button to the Left:
//                      Right
//             Forward          Backward
//                      Left

static void updateCoordinates() {
  struct coordinates temp_F;
  struct coordinates temp_R;
  struct coordinates temp_B;
  struct coordinates temp_L;

  temp_F.x_neg = forward.x_neg;
  temp_F.y_neg = forward.y_neg;
  temp_F.z_neg = forward.z_neg;

  temp_L.x_neg = left.x_neg;
  temp_L.y_neg = left.y_neg;
  temp_L.z_neg = left.z_neg;

  temp_R.x_neg = right.x_neg;
  temp_R.y_neg = right.y_neg;
  temp_R.z_neg = right.z_neg;

  temp_B.x_neg = backward.x_neg;
  temp_B.y_neg = backward.y_neg;
  temp_B.z_neg = backward.z_neg;

  if (Right) {
    forward.x_neg = temp_R.x_neg;
    forward.y_neg = temp_R.y_neg;
    forward.z_neg = temp_R.z_neg;

    left.x_neg = temp_F.x_neg;
    left.y_neg = temp_F.y_neg;
    left.z_neg = temp_F.z_neg;

    right.x_neg = temp_B.x_neg;
    right.y_neg = temp_B.y_neg;
    right.z_neg = temp_B.z_neg;

    backward.x_neg = temp_L.x_neg;
    backward.y_neg = temp_L.y_neg;
    backward.z_neg = temp_L.z_neg;
  }
  else if (Left) {
    forward.x_neg = temp_L.x_neg;
    forward.y_neg = temp_L.y_neg;
    forward.z_neg = temp_L.z_neg;

    left.x_neg = temp_B.x_neg;
    left.y_neg = temp_B.y_neg;
    left.z_neg = temp_B.z_neg;

    right.x_neg = temp_F.x_neg;
    right.y_neg = temp_F.y_neg;
    right.z_neg = temp_F.z_neg;

    backward.x_neg = temp_R.x_neg;
    backward.y_neg = temp_R.y_neg;
    backward.z_neg = temp_R.z_neg;
  }
  else if (Backward) {
    forward.x_neg = temp_B.x_neg;
    forward.y_neg = temp_B.y_neg;
    forward.z_neg = temp_B.z_neg;

    left.x_neg = temp_R.x_neg;
    left.y_neg = temp_R.y_neg;
    left.z_neg = temp_R.z_neg;

    right.x_neg = temp_L.x_neg;
    right.y_neg = temp_L.y_neg;
    right.z_neg = temp_L.z_neg;

    backward.x_neg = temp_F.x_neg;
    backward.y_neg = temp_F.y_neg;
    backward.z_neg = temp_F.z_neg;
  }

}

// lose_Life(), Pass_level() and lost() turn off some LED in order to give an output to the Player.
static void lose_Life() {
  chprintf(chp, "life: %d\r\n", life);

  palToggleLine(LINE_LED8_ORANGE);
  palToggleLine(LINE_LED9_BLUE);
  palToggleLine(LINE_LED5_ORANGE);
  palToggleLine(LINE_LED4_BLUE);

  chThdSleepMilliseconds(500);

  palToggleLine(LINE_LED8_ORANGE);
  palToggleLine(LINE_LED9_BLUE);
  palToggleLine(LINE_LED5_ORANGE);
  palToggleLine(LINE_LED4_BLUE);

  chThdSleepMilliseconds(50);
}
static void Pass_level() {
  palToggleLine(LINE_LED10_RED);
  chThdSleepMilliseconds(50);
  palToggleLine(LINE_LED8_ORANGE);
  chThdSleepMilliseconds(50);
  palToggleLine(LINE_LED6_GREEN);
  chThdSleepMilliseconds(50);
  palToggleLine(LINE_LED4_BLUE);
  chThdSleepMilliseconds(50);
  palToggleLine(LINE_LED3_RED);
  chThdSleepMilliseconds(50);
  palToggleLine(LINE_LED5_ORANGE);
  chThdSleepMilliseconds(50);
  palToggleLine(LINE_LED7_GREEN);
  chThdSleepMilliseconds(50);
  palToggleLine(LINE_LED9_BLUE);
  chThdSleepMilliseconds(1000);

  palToggleLine(LINE_LED10_RED);
  chThdSleepMilliseconds(50);
  palToggleLine(LINE_LED8_ORANGE);
  chThdSleepMilliseconds(50);
  palToggleLine(LINE_LED6_GREEN);
  chThdSleepMilliseconds(50);
  palToggleLine(LINE_LED4_BLUE);
  chThdSleepMilliseconds(50);
  palToggleLine(LINE_LED3_RED);
  chThdSleepMilliseconds(50);
  palToggleLine(LINE_LED5_ORANGE);
  chThdSleepMilliseconds(50);
  palToggleLine(LINE_LED7_GREEN);
  chThdSleepMilliseconds(50);
  palToggleLine(LINE_LED9_BLUE);
  chThdSleepMilliseconds(1000);

}
static void lost() {
  palToggleLine(LINE_LED10_RED);
  palToggleLine(LINE_LED3_RED);
  chThdSleepMilliseconds(50);
  palToggleLine(LINE_LED10_RED);
  palToggleLine(LINE_LED3_RED);

  palToggleLine(LINE_LED8_ORANGE);
  palToggleLine(LINE_LED5_ORANGE);
  chThdSleepMilliseconds(50);
  palToggleLine(LINE_LED8_ORANGE);
  palToggleLine(LINE_LED5_ORANGE);

  palToggleLine(LINE_LED6_GREEN);
  palToggleLine(LINE_LED7_GREEN);
  chThdSleepMilliseconds(50);
  palToggleLine(LINE_LED6_GREEN);
  palToggleLine(LINE_LED7_GREEN);

  palToggleLine(LINE_LED4_BLUE);
  palToggleLine(LINE_LED9_BLUE);
  chThdSleepMilliseconds(50);
  palToggleLine(LINE_LED4_BLUE);
  palToggleLine(LINE_LED9_BLUE);

}

//This function restart to the initial Coordinates.
//                      Forward
//               Left            Right
//                      Backward
static void restart() {
  forward.x_neg = orig_F.x_neg;
  forward.y_neg = orig_F.y_neg;
  forward.z_neg = orig_F.z_neg;

  left.x_neg = orig_L.x_neg;
  left.y_neg = orig_L.y_neg;
  left.z_neg = orig_L.z_neg;

  right.x_neg = orig_R.x_neg;
  right.y_neg = orig_R.y_neg;
  right.z_neg = orig_R.z_neg;

  backward.x_neg = orig_B.x_neg;
  backward.y_neg = orig_B.y_neg;
  backward.z_neg = orig_B.z_neg;
}


static THD_WORKING_AREA(waThread1, 128);
static THD_FUNCTION(Thread1, arg) {
  chRegSetThreadName("play: ");
  while (true) {

    chMtxLock(&mtx1);
    if (life == 0) {
      chprintf(chp, "you lose all life, press the button to restart\r\n");
      while (!palReadPad(GPIOA, GPIOA_BUTTON)) {
        chprintf(chp, "(S)KIL(LED) \r");
        lost();
        chThdSleepMilliseconds(50);
      }
      life = 3;
      score = 0;
      restart();
      chThdSleepMilliseconds(400);
    }
    if (life > 0) {
      r = (rand() % 4) + 1;
      whoIsR();
      chThdSleepMilliseconds(50);
    }

    while (!palReadPad(GPIOA, GPIOA_BUTTON)) {
      chThdSleepMilliseconds(50);
    }
    chThdSleepMilliseconds(400);
    chMtxUnlock(&mtx1);
  }
}

static THD_WORKING_AREA(waThread2, 128);
static THD_FUNCTION(Thread2, arg) {
  bool flag;
  chRegSetThreadName("shot it: ");
  while (true) {

    chMtxLock(&mtx1);

    readData();

    isRight();
    isLeft();
    isBackward();
    isForward();

    flag = isKilledEnemy();
    updateCoordinates();
    clear_LED();

    if (flag) {
      score = score + 10;
      if ((score % 60) == 0) {
        life = life + 1;
        Pass_level();
      }
    }
    else if (!flag) {
      life = life - 1;
      lose_Life();
    }
    chThdSleepMilliseconds(400);
    chMtxUnlock(&mtx1);
  }

}

/*
 * Application entry point.
 */
static void cmd_PLAY(BaseSequentialStream *chp, int argc, char *argv[]) {
  chprintf(chp, "start function");
  chMtxUnlock(&mtx1);
}
static void cmd_SETUP(BaseSequentialStream *chp, int argc, char *argv[]) {
  chprintf(chp,
           "Welcome, first of all we start to configure your location.\r\n");
  chThdSleepMilliseconds(500);
  chprintf(
      chp,
      "read on the terminal where you have to move and rotate the gun in that direction.\r\n");
  chThdSleepMilliseconds(500);
  setRight();
  chThdSleepMilliseconds(500);
  setLeft();
  chThdSleepMilliseconds(500);
  setForward();
  chThdSleepMilliseconds(500);
  setBackward();
  chThdSleepMilliseconds(500);
  chprintf(chp, "Configuration done!\r\n");
}

//The commands that the shell use
static const ShellCommand commands[] = {

{"PLAY", cmd_PLAY},
                                        {"SETUP", cmd_SETUP}, {NULL, NULL}};

//shell configuration keeps the Serial Driver that we want to use, and a list of commands.
static const ShellConfig shell_cfg1 = {(BaseSequentialStream *)&SD1, commands};

int main(void) {

  halInit();
  chSysInit();

  /* Activates the serial driver 1 using the driver default configuration.*/
  sdStart(&SD1, NULL);

  //initialize the Compass & configure it by using the Init & start function.
  lsm303dlhcObjectInit(&LSM303DLHCD1);
  lsm303dlhcStart(&LSM303DLHCD1, &lsm303dlhccfg);

  //initialize the mutex
  chMtxObjectInit(&mtx1);


  chMtxLock(&mtx1);

  //create the two thread: "Play" and "Shoot it"
  chThdCreateStatic(waThread1, sizeof(waThread1), NORMALPRIO, Thread1, NULL);
  chThdCreateStatic(waThread2, sizeof(waThread2), NORMALPRIO, Thread2, NULL);

  srand(41);

  //Create the shell thread and wait until it's terminated.
  while (true) {
    thread_t *shelltp = chThdCreateFromHeap(NULL, SHELL_WA_SIZE, "shell",
    NORMALPRIO + 1,
                                            shellThread, (void *)&shell_cfg1);
    chThdWait(shelltp); /* Waiting termination.             */

  }

  chThdSleepMilliseconds(100);
  cls(chp);
}
